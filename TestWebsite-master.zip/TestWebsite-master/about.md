---
layout: page
title: About
permalink: /about/
published: true
---

## About Me

Hi there! My name is Evan Perry and I'm a Junior majoring in Economics and Math at Coe College in Cedar Rapids, Iowa. My main interests are in environmental economics, but I like to dabble in other areas of microeconomics too. Outside of school, I enjoy hiking, backpacking, and music, etc.

## About the Blog

This is a blog and it does some things that like I mean yeah.

### Contact me

[eaperry19@coe.edu](mailto:eaperry19@coe.edu)
